import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Compass,
  Mail,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  TrendingUp,
  Target,
  ShieldCheck,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function LoginPage() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState<'student' | 'admin'>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(role === 'student' ? '/student/dashboard' : '/admin/dashboard');
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Left showcase panel */}
      <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden bg-gradient-to-br from-primary via-primary to-chart-2 p-12 text-primary-foreground lg:flex">
        {/* Decorative orbs */}
        <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute right-10 top-1/3 h-64 w-64 rounded-full bg-white/5 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-chart-2/20 blur-3xl" />

        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/15 backdrop-blur-sm">
              <Compass className="h-6 w-6" />
            </div>
            <div>
              <p className="text-lg font-bold leading-tight">Career Compass</p>
              <p className="text-xs font-medium uppercase tracking-wider text-primary-foreground/70">
                AI Placement Platform
              </p>
            </div>
          </div>
        </div>

        <div className="relative z-10 space-y-8">
          <div className="space-y-4">
            <h1 className="text-4xl font-bold leading-tight tracking-tight">
              Navigate your career
              <br />
              with AI precision.
            </h1>
            <p className="max-w-md text-base text-primary-foreground/80">
              Smart job matching, skill gap analysis, and real-time placement
              readiness — all in one intelligent dashboard.
            </p>
          </div>

          <div className="grid gap-4">
            {[
              { icon: Target, title: 'AI Job Matching', desc: '94% match accuracy with personalized recommendations' },
              { icon: TrendingUp, title: 'Readiness Score', desc: 'Track your placement readiness in real-time' },
              { icon: ShieldCheck, title: 'Verified Companies', desc: '500+ trusted recruiters actively hiring' },
            ].map((feature) => (
              <div key={feature.title} className="flex items-start gap-3 rounded-xl bg-white/10 p-3 backdrop-blur-sm">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/15">
                  <feature.icon className="h-4.5 w-4.5" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{feature.title}</p>
                  <p className="text-xs text-primary-foreground/70">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10 flex items-center gap-6 text-sm text-primary-foreground/70">
          <span>500+ Companies</span>
          <span className="h-1 w-1 rounded-full bg-primary-foreground/40" />
          <span>10k+ Students</span>
          <span className="h-1 w-1 rounded-full bg-primary-foreground/40" />
          <span>85% Placement Rate</span>
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex w-full flex-col items-center justify-center px-6 py-12 lg:w-1/2">
        <div className="w-full max-w-sm space-y-8">
          {/* Mobile logo */}
          <div className="flex items-center justify-center gap-2.5 lg:hidden">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <Compass className="h-5 w-5" />
            </div>
            <div>
              <p className="text-base font-bold">Career Compass</p>
              <p className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                AI Platform
              </p>
            </div>
          </div>

          <div className="space-y-2 text-center">
            <h2 className="text-2xl font-bold tracking-tight">Welcome back</h2>
            <p className="text-sm text-muted-foreground">
              Sign in to access your dashboard
            </p>
          </div>

          <Tabs value={role} onValueChange={(v) => setRole(v as 'student' | 'admin')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="student">Student</TabsTrigger>
              <TabsTrigger value="admin">Admin</TabsTrigger>
            </TabsList>
          </Tabs>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="you@college.edu"
                  className="pl-9"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <button type="button" className="text-xs font-medium text-primary hover:underline">
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  className="pl-9 pr-9"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button type="submit" className="w-full" size="lg">
              Sign In
              <ArrowRight className="ml-1.5 h-4 w-4" />
            </Button>
          </form>

          <Card className="border-dashed bg-secondary/30">
            <CardContent className="flex items-center gap-3 p-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Sparkles className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-semibold">Demo Mode</p>
                <p className="text-[11px] text-muted-foreground">
                  Use any email and password to explore the platform.
                </p>
              </div>
            </CardContent>
          </Card>

          <p className="text-center text-xs text-muted-foreground">
            Don't have an account?{' '}
            <button className="font-medium text-primary hover:underline">
              Contact your placement cell
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
