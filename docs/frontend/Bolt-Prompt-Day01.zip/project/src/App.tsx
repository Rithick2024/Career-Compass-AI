import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from '@/features/auth/pages/LoginPage';
import StudentDashboard from '@/features/student/pages/StudentDashboard';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<LoginPage />} />

        {/* Student module */}
        <Route path="/student/dashboard" element={<StudentDashboard />} />

        {/* Placeholder routes for remaining student pages */}
        {['profile', 'skills', 'resume', 'jobs', 'applications', 'readiness'].map((p) => (
          <Route
            key={p}
            path={`/student/${p}`}
            element={<StudentDashboard />}
          />
        ))}

        {/* Admin module placeholder */}
        {['dashboard', 'students', 'companies', 'jobs', 'analytics'].map((p) => (
          <Route
            key={p}
            path={`/admin/${p}`}
            element={<StudentDashboard />}
          />
        ))}

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
