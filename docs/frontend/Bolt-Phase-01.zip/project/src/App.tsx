import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from '@/features/auth/pages/LoginPage';
import StudentDashboard from '@/features/student/pages/StudentDashboard';
import StudentProfile from '@/features/student/pages/StudentProfile';
import StudentSkills from '@/features/student/pages/StudentSkills';
import StudentResume from '@/features/student/pages/StudentResume';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<LoginPage />} />

        {/* Student module */}
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        <Route path="/student/profile" element={<StudentProfile />} />
        <Route path="/student/skills" element={<StudentSkills />} />
        <Route path="/student/resume" element={<StudentResume />} />

        {/* Placeholder routes for remaining student pages */}
        {['jobs', 'applications', 'readiness'].map((p) => (
          <Route
            key={p}
            path={`/student/${p}`}
            element={<StudentDashboard />}
          />
        ))}

        {/* Admin module placeholder */}
        {['dashboard', 'students', 'companies', 'jobs', 'analytics'].map((p) => (
          <Route
            key={p}
            path={`/admin/${p}`}
            element={<StudentDashboard />}
          />
        ))}

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
